# Bibliomuni

# Lanzar la app
Primero correr  para instalar las dependencias
```bash
npm install
```
luego
tipear 
```bash
ng serve
``` 
para lanzarlo en `http://localhost:4200/`.