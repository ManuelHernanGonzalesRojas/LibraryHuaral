export const environment = {
    production: false,
    endpoint: 'http://localhost:3000/',
    isbn: 'http://localhost:5000/',
    portrait: 'http://localhost:5001/'
};
